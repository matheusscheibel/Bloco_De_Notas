Aplicação em flutter de um bloco de notas criado por Matheus Scheibel Pereira para a disciplina de programação de dispositivos moveis. 
